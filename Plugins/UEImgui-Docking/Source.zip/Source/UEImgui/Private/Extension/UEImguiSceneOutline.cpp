#include "Extension/UEImguiSceneOutline.h"

FUEImguiSceneOutline::FUEImguiSceneOutline(UObject* InWorldContext)
{
	// FWorldDelegates::LevelAddedToWorld;
	// FWorldDelegates::LevelRemovedFromWorld;
	// GWorld->AddOnActorSpawnedHandler();
	// Destroyed
}

FUEImguiSceneOutline::~FUEImguiSceneOutline()
{
	// FWorldDelegates::LevelAddedToWorld;
	// FWorldDelegates::LevelRemovedFromWorld;
	// GWorld->RemoveOnActorSpawnedHandler();
}
