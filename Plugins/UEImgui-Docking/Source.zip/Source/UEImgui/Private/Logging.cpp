#include "Logging.h"

DEFINE_LOG_CATEGORY(LogUEImgui);