namespace slua
{
	struct lua_State;
}

void UEIMGUI_API LoadImguiBindings(slua::lua_State* lState);