// Fill out your copyright notice in the Description page of Project Settings.

#include "Logging.h"

DEFINE_LOG_CATEGORY(UEImguiEditor);